<?php

namespace Modules\Product\Models;

use Illuminate\Database\Eloquent\Model;

class Product_list extends Model
{
    protected $table = 'products_lists';
}
