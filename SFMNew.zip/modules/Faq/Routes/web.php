<?php

/*
|--------------------------------------------------------------------------
| Module Web Routes
|--------------------------------------------------------------------------
*/

//Route::prefix('backend')->middleware('auth')->group(function () {
//        Route::get('/faq', 'backend\BackendModuleFaqController@index')->name('backend.faq.index');
//        Route::get('/faq/create', 'backend\BackendModuleFaqController@create')->name('backend.faq.create');
//});
//
//Route::get('/faq', 'frontend\FrontendModuleFaqController@index')->name('frontend.faq.index');
