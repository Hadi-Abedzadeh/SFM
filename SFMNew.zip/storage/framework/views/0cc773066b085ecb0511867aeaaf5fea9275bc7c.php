<?php $__env->startSection('content'); ?>

    <div class="singleheader">
        <div class="singlecover"><img src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/background.jpg"></div>
        <a href="<?php echo e(route('frontend.blog.index')); ?>" class="singleback"><span class="icon-back"></span>BACK TO BLOG</a>
    </div>
    <div class="singleheaderclear"></div>
    <div class="container-fluid">
        <div class="singlecontent">
            <h1><?php echo e($post->title); ?></h1>
            <p><?php echo e($post->body); ?></p>
        </div>

        <div class="swipeslider">
            <h2>SIMILAR <span>POSTS</span></h2>
            <div class="owl-carousel">
                <?php for($i =0; $i <=2;$i++): ?>
                    <div class="newsproduct">
                        <div class="newsproductthumb">
                            <img src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/newsthumb.jpg" draggable="false">
                        </div>
                        <div class="newsproductcontent">
                            <h4>NEW POST</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua …</p>
                            <a href="#" class="newsproductmore">VIEW MORE</a>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
	Blog <?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>