<?php $__env->startSection('content'); ?>
    <main id="product-page">
        <div class="container">
    <section class="product-section">
        <div class="title">
            <h2><span>محصولات</span>ما</h2> دسته بندی
            <span><?php echo e($category); ?></span>
        </div>
        <div class="content">

            <div class="products">
                <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-xl-8 col-lg-8 col-md-12 col-sm-24 item active">
                            <div class="items">
                                <a href="<?php echo e(route('frontend.product.show', ['slug'=>$product->slug])); ?>">
                                    <img src="/<?php echo e(env('THEME_NAME_FA')); ?>/assets/images/sample/product-1.png" title="" alt="">
                                    <span class="cost"><?php echo e($product->title); ?></span>
                                    <span class="more-info">اطــــلاعــاتـــــــ بــیــــشــــتـــــــر</span>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>
        </div></main>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    محصولات
    <?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.frontend-fa.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>