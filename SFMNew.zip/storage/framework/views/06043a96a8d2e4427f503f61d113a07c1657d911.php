<?php $__env->startSection('content'); ?>

    

    <div class="container-fluid">

        <div class="singleproduct">
            <div class="singleproductside">
                <h3><?php echo e($product_list->title); ?></h3>
                <div class="khat"><span>COLORS:</span> White, Black, Gray, Silver
                    <div class="colors">
                        <div class="color white"></div>
                        <div class="color black"></div>
                        <div class="color gray"></div>
                        <div class="color silver"></div>
                    </div>
                </div>
                <div class="khat"><span>FUNCTION:</span></div>
                <div class="row">
                    <div class="col">
                        <span>ROTISSRIE</span>
                        <span>CONVECTION</span>
                        <span>REFLEX GLASS</span>
                    </div>
                    <div class="col">
                        <span>COOKING TRAY</span>
                        <span>LACE GRILL</span>
                        <span>DEFROST PROGRAM</span>
                    </div>
                    <div class="col">
                        <span>TRAY KNOB</span>
                        <span>OIL TRAY</span>
                    </div>
                    <div class="col">
                        <span>ROTISSERIE KNOB</span>
                        <span>INNER LAMP</span>
                    </div>
                </div>
                <a href="#" class="btn">CATALOGE DOWNLOAD</a>
            </div>
            <div class="singleproductimg">
                <div><img src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/main-product.png" draggable="false"></div>
            </div>
        </div>
        <div class="owl-carousel productsarea">


            <?php $__currentLoopData = $same_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $same_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product micro1 active">
                    <div class="productthumb"><img src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/product-2.png"
                                                   draggable="false"></div>
                    <div class="producttitle">    <?php echo e($same_product->title); ?></div>
                    <a href="<?php echo e(route('frontend.product.show',['slug' => $same_product->slug])); ?>" class="productmore">VIEW
                        MORE</a>
                </div>




            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($same_product->title); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>