<?php $__env->startSection('content'); ?>



<div class="container-fluid">

<div class="sectionheader">
<h2>OUR <span>PRODUCTS</span></h2>
<h3>WHO WE ARE?</h3>
</div>
<div class="flexheader">
<div class="sorter">
<a class="active" data-cat="product">ALL</a>
<a data-cat="A-juicer">juicer</a>
<a data-cat="A-microwave">microwave</a>
<a data-cat="A-vacuum-cleaner">vacuum cleaner</a>
<a data-cat="A-heater">heater</a>
</div>
<div class="searchbox">
<button><div class="icon"></div></button>
<input type="text" placeholder="SEARCH ...">
</div>
</div>
<div class="productsarea">


        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	<a  href="<?php echo e(route('frontend.product.show',['slug'=>$product->slug])); ?>" class="product A-<?php echo e($product->category); ?> active">
	<div class="productthumb"><img src="/<?php echo e(env('THEME_NAME')); ?>/assets/images/product-2.png" draggable="false"></div>
	<div class="producttitle">9090</div>
	<span class="productmore">VIEW MORE</span>
	</a>
			
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
	Products
<?php $__env->stopSection(); ?>
<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>