<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="singlecontent">
            <div class="sectionheader">
                <h2><?php echo $about->title_en; ?></h2>
            </div>
            <p>
                <?php echo $about->body_en; ?>

            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', $about->title_en); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>