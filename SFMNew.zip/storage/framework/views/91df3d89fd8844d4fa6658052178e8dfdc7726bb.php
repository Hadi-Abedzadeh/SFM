<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="newsproductarea">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="newsproduct">
                <div class="newsproductthumb"><img src="<?php echo e($report->imageUrl); ?>" draggable="false"></div>
                <div class="newsproductcontent">
                    <h4><?php echo e($report->title); ?></h4>
                    <p>
                        <?php echo e(substr(strip_tags($report->body), 0, 300)); ?>

                        <?php echo e(strlen(strip_tags($report->body)) > 50 ? "..." : ""); ?>

                    </p>
                    <a href="<?php echo e(route('frontend.news.index.show',['slug'=>$report->slug])); ?>" class="newsproductmore">VIEW MORE</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    News
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>