<?php $__env->startSection('content'); ?>
    <main id="faq-page">
        <div class="container">
            <section class="faq-section">
                <div class="title">
                    <h2><span>پرسش</span> و <span>پاسخ</span></h2>
                    <span>سوالات متداول</span>
                </div>
                <div class="content row">

                    <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-24">
                            <div class="item">
                                <div class="number"><span><?php echo e($loop->iteration); ?></span></div>
                                <div class="question"><h5><?php echo e($q->question); ?></h5>
                                </div>
                                <div class="answer"><p>
                                        <?php echo e($q->answer); ?>

                                    </p></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    پرسش و پاسخ
<?php $__env->stopSection(); ?>

<?php echo $__env->make(env('THEME_NAME').'.frontend-fa.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>